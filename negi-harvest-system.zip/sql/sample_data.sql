INSERT INTO loss_types (id, name) VALUES
(1, 'OK'),
(2, 'GOMI');

INSERT INTO users (id, name) VALUES
(1, '山田'),
(2, '佐藤');

INSERT INTO beds (id, name, group_type) VALUES
(1, 'A-1', '通常'),
(2, 'B-1', '別宅');
